
-- --------------------------------------------------------

--
-- Table structure for table `pupils`
--
-- Creation: Apr 07, 2021 at 06:15 AM
--

CREATE TABLE `pupils` (
  `id` int(7) NOT NULL,
  `surname` varchar(30) NOT NULL,
  `name` varchar(30) NOT NULL,
  `middlename` varchar(30) NOT NULL,
  `address` text NOT NULL,
  `grade` int(1) DEFAULT 1,
  `phone` varchar(10) DEFAULT NULL,
  `birth_date` date DEFAULT NULL,
  `faculty_id` int(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pupils`
--

INSERT INTO `pupils` (`id`, `surname`, `name`, `middlename`, `address`, `grade`, `phone`, `birth_date`, `faculty_id`) VALUES
(1, 'Jurayev', 'Mansu\'&quot;\\&quot;r', 'O\'ktam o\'g\'li', 'Chiroqchi tumani Navruz qishlog\'i 91-uy', 1, '996672106', '2020-11-01', 12904),
(3, 'Malikov', 'Muhiddin', 'Odil o\'g\'li', 'Chiroqchi tumani Navruz qishlog\'i', 1, '99667210', '2020-11-24', 12910),
(37, 'kjhkjhkj', 'jkhjkhjk', 'kjhjkh', 'kjhkjhjk', 2, '12121212', '2001-12-12', 12904),
(39, ';\'\'als;\'', 'asd', 'mnbnbnmb', 'kasdkjlaskhdkljashlkd', 2, '996672106', '2020-10-29', 12910),
(41, 'asass', 'asas', '2323', 'asass', 2, '23232323', '2020-11-11', 12899);
