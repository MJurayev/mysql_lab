
-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--
-- Creation: Apr 07, 2021 at 06:16 AM
--

CREATE TABLE `subjects` (
  `id` int(7) NOT NULL,
  `name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`id`, `name`) VALUES
(2, 'Marematika fanlari'),
(3, 'Fizika'),
(4, 'CHQBT'),
(5, 'Avtomobil tuzilishi'),
(6, 'ATX'),
(7, 'Ingliz tili'),
(8, 'Algebra');
