
-- --------------------------------------------------------

--
-- Structure for view `marks_view`
--
DROP TABLE IF EXISTS `marks_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`%` SQL SECURITY DEFINER VIEW `marks_view`  AS  select `lessons`.`id` AS `id`,concat(`pupils`.`surname`,' ',`pupils`.`name`,' ',`pupils`.`middlename`) AS `FISH`,(select `subjects`.`name` from `subjects` where `subjects`.`id` = `lessons`.`subject_id`) AS `subject`,`marks`.`mark` AS `mark` from ((`marks` join `lessons` on(`marks`.`lesson_id` = `lessons`.`id`)) join `pupils` on(`marks`.`pupil_id` = `pupils`.`id`)) ;
