
-- --------------------------------------------------------

--
-- Structure for view `pupils_view`
--
DROP TABLE IF EXISTS `pupils_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`%` SQL SECURITY DEFINER VIEW `pupils_view`  AS  select `pupils`.`id` AS `id`,`pupils`.`surname` AS `surname`,`pupils`.`name` AS `name`,`pupils`.`middlename` AS `middlename`,`pupils`.`address` AS `address`,`pupils`.`grade` AS `grade`,`pupils`.`phone` AS `phone`,`pupils`.`birth_date` AS `birth_date`,`faculty`.`name` AS `faculty` from (`pupils` join `faculty` on(`pupils`.`faculty_id` = `faculty`.`id`)) ;
