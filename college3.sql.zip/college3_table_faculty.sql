
-- --------------------------------------------------------

--
-- Table structure for table `faculty`
--
-- Creation: Apr 07, 2021 at 06:14 AM
-- Last update: Apr 07, 2021 at 06:17 AM
--

CREATE TABLE `faculty` (
  `id` int(7) NOT NULL,
  `name` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `faculty`
--

INSERT INTO `faculty` (`id`, `name`) VALUES
(12899, 'Avtomobil sozlik'),
(12904, 'Qayta ishlash texnolosgiyalari'),
(12907, 'asd'),
(12908, 'asdasd'),
(12909, 'kjhaklkj'),
(12910, 'asdasdasdasd'),
(12911, 'deleted2121'),
(12912, 'sdf');
