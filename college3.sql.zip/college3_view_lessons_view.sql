
-- --------------------------------------------------------

--
-- Structure for view `lessons_view`
--
DROP TABLE IF EXISTS `lessons_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`%` SQL SECURITY DEFINER VIEW `lessons_view`  AS  select `lessons`.`id` AS `id`,`employees`.`surname` AS `employee_surname`,`employees`.`name` AS `employee_name`,`employees`.`middlename` AS `employee_middlename`,`pupils`.`surname` AS `pupils_surname`,`pupils`.`name` AS `pupils_name`,`pupils`.`middlename` AS `pupils_middlename`,`subjects`.`name` AS `subject`,`lessons`.`para` AS `para`,`lessons`.`day_of_week` AS `day_of_week` from (((`lessons` join `employees` on(`lessons`.`employee_id` = `employees`.`id`)) join `pupils` on(`lessons`.`pupil_id` = `pupils`.`id`)) join `subjects` on(`lessons`.`subject_id` = `subjects`.`id`)) ;
