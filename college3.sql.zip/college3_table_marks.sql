
-- --------------------------------------------------------

--
-- Table structure for table `marks`
--
-- Creation: Apr 07, 2021 at 06:15 AM
-- Last update: Apr 07, 2021 at 06:36 AM
--

CREATE TABLE `marks` (
  `id` int(11) NOT NULL,
  `pupil_id` int(7) DEFAULT NULL,
  `lesson_id` int(7) DEFAULT NULL,
  `mark` int(3) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `marks`
--

INSERT INTO `marks` (`id`, `pupil_id`, `lesson_id`, `mark`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 4, '2020-11-23 16:15:26', '2020-11-23 16:17:54'),
(2, 2, 1, 5, '2020-11-23 16:15:26', '2020-11-23 16:17:54'),
(3, 1, 1, 3, '2020-11-28 07:10:04', '2020-11-28 07:10:04'),
(4, 1, 5, 3, '2021-04-07 06:34:41', '2021-04-07 06:34:41'),
(5, 1, 5, 3, '2021-04-07 06:35:19', '2021-04-07 06:35:19'),
(6, 37, 3, 4, '2021-04-07 06:36:27', '2021-04-07 06:36:27');
