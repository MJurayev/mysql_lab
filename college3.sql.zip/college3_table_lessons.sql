
-- --------------------------------------------------------

--
-- Table structure for table `lessons`
--
-- Creation: Apr 07, 2021 at 05:47 AM
-- Last update: Apr 07, 2021 at 06:17 AM
--

CREATE TABLE `lessons` (
  `id` int(11) NOT NULL,
  `employee_id` int(7) NOT NULL,
  `pupil_id` int(7) DEFAULT NULL,
  `subject_id` int(7) DEFAULT NULL,
  `day_of_week` varchar(20) DEFAULT NULL,
  `para` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `lessons`
--

INSERT INTO `lessons` (`id`, `employee_id`, `pupil_id`, `subject_id`, `day_of_week`, `para`) VALUES
(1, 3, 3, 5, 'Dushanba', 1),
(2, 4, 3, 6, 'Dushanba', 1),
(3, 4, 2, 6, 'Dushanba', 1),
(4, 4, 2, 6, 'Dushanba', 2),
(5, 3, 1, 3, 'Chorshanba', 2),
(6, 3, 1, 2, 'Dushanba', 3),
(7, 3, 1, 2, 'Dushanba', 3),
(8, 3, 1, 2, 'Dushanba', 3),
(9, 3, 3, 4, 'Seshanba', 3);
