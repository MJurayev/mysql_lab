
-- --------------------------------------------------------

--
-- Table structure for table `employees`
--
-- Creation: Apr 07, 2021 at 06:15 AM
--

CREATE TABLE `employees` (
  `id` int(7) NOT NULL,
  `surname` varchar(30) NOT NULL,
  `name` varchar(30) NOT NULL,
  `middlename` varchar(30) NOT NULL,
  `address` text NOT NULL,
  `stage` int(2) DEFAULT 0,
  `phone` varchar(10) DEFAULT NULL,
  `birth_date` date DEFAULT NULL,
  `category` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`id`, `surname`, `name`, `middlename`, `address`, `stage`, `phone`, `birth_date`, `category`) VALUES
(3, 'Jurayev', 'Mansur', 'O\'ktam o\'g\'li', 'Chiroqchi tumani Navruz qishlog\'i', 1, '996672106', '2018-11-07', 'o\'rta'),
(4, 'Malikov', 'Muhiddin', 'Odil o\'g\'li', 'Chiroqchi', 2, '992323233', '2000-10-05', 'oliy');
